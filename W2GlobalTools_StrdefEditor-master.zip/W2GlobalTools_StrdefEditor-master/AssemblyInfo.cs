﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("W2 - Strdef Editor")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("W2 - Strdef Editor")]
[assembly: AssemblyCopyright("Copyright © Seitbnao  2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("722080d0-73ee-4734-8ff8-c3c87cc525d3")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
