﻿ 
namespace W2___Strdef_Editor.Funções
{
  internal class External : Structs
  {
    public static Structs.STRUCT_STRDEF g_pStrdef = new Structs.STRUCT_STRDEF();
 
    public static int Index = -1;
 
  }
}
