﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W2___MountData_Editor.Funções
{
    class External : Structs
    {
        public static STRUCT_MOUNTDATA g_pMountData = new STRUCT_MOUNTDATA();

        
        static public int Index = -1;
        static public int Version = 7559;
         
    }
}