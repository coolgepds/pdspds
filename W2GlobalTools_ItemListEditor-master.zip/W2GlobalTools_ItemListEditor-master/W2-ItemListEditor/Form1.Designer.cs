﻿namespace ItemListEditor
{
	partial class W2_ItemListEditor
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(W2_ItemListEditor));
            this.listBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.EF1 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.EF2 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.EF3 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.EF4 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.EF5 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.EF6 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.EF7 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.EF8 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.EF9 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.EF10 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.EF11 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.EF12 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.EFV12 = new System.Windows.Forms.NumericUpDown();
            this.EFV11 = new System.Windows.Forms.NumericUpDown();
            this.EFV10 = new System.Windows.Forms.NumericUpDown();
            this.EFV9 = new System.Windows.Forms.NumericUpDown();
            this.EFV8 = new System.Windows.Forms.NumericUpDown();
            this.EFV7 = new System.Windows.Forms.NumericUpDown();
            this.EFV6 = new System.Windows.Forms.NumericUpDown();
            this.EFV5 = new System.Windows.Forms.NumericUpDown();
            this.EFV4 = new System.Windows.Forms.NumericUpDown();
            this.EFV3 = new System.Windows.Forms.NumericUpDown();
            this.EFV2 = new System.Windows.Forms.NumericUpDown();
            this.EFV1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.Visual = new System.Windows.Forms.NumericUpDown();
            this.UNK4 = new System.Windows.Forms.NumericUpDown();
            this.UNK3 = new System.Windows.Forms.NumericUpDown();
            this.UNK2 = new System.Windows.Forms.NumericUpDown();
            this.UNK1 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.grau = new System.Windows.Forms.NumericUpDown();
            this.anct = new System.Windows.Forms.NumericUpDown();
            this.unique = new System.Windows.Forms.NumericUpDown();
            this.preco = new System.Windows.Forms.NumericUpDown();
            this.constituicao = new System.Windows.Forms.NumericUpDown();
            this.destreza = new System.Windows.Forms.NumericUpDown();
            this.inteligencia = new System.Windows.Forms.NumericUpDown();
            this.forca = new System.Windows.Forms.NumericUpDown();
            this.level = new System.Windows.Forms.NumericUpDown();
            this.textura = new System.Windows.Forms.NumericUpDown();
            this.mesh = new System.Windows.Forms.NumericUpDown();
            this.save = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.saveall = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.posicao = new System.Windows.Forms.TextBox();
            this.slot17 = new System.Windows.Forms.CheckBox();
            this.slot16 = new System.Windows.Forms.CheckBox();
            this.slot15 = new System.Windows.Forms.CheckBox();
            this.slot14 = new System.Windows.Forms.CheckBox();
            this.slot13 = new System.Windows.Forms.CheckBox();
            this.slot12 = new System.Windows.Forms.CheckBox();
            this.slot11 = new System.Windows.Forms.CheckBox();
            this.slot10 = new System.Windows.Forms.CheckBox();
            this.slot9 = new System.Windows.Forms.CheckBox();
            this.slot8 = new System.Windows.Forms.CheckBox();
            this.slot7 = new System.Windows.Forms.CheckBox();
            this.slot6 = new System.Windows.Forms.CheckBox();
            this.slot5 = new System.Windows.Forms.CheckBox();
            this.slot4 = new System.Windows.Forms.CheckBox();
            this.slot3 = new System.Windows.Forms.CheckBox();
            this.slot2 = new System.Windows.Forms.CheckBox();
            this.slot1 = new System.Windows.Forms.CheckBox();
            this.slot0 = new System.Windows.Forms.CheckBox();
            this.export = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.itemBox = new System.Windows.Forms.GroupBox();
            this.clean = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.Pesquisa = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirItemNamebinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirItemListbinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarItemListbinEncodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarItemListbinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerarItemNamecsvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarItemNamebinToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gerarItemNamecsvToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editorDeItemIonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EFV12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Visual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unique)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.preco)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.constituicao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.destreza)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inteligencia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.forca)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textura)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mesh)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.itemBox.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.IntegralHeight = false;
            this.listBox.Location = new System.Drawing.Point(5, 75);
            this.listBox.Margin = new System.Windows.Forms.Padding(1);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(220, 342);
            this.listBox.TabIndex = 0;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(5, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "ItemName";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(5, 34);
            this.name.Margin = new System.Windows.Forms.Padding(1);
            this.name.MaxLength = 64;
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(210, 21);
            this.name.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(5, 60);
            this.label2.Margin = new System.Windows.Forms.Padding(1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "3DObject";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(5, 103);
            this.label3.Margin = new System.Windows.Forms.Padding(1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(210, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Level Requerido:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(5, 146);
            this.label4.Margin = new System.Windows.Forms.Padding(1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(210, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Força Nescessária:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(5, 189);
            this.label5.Margin = new System.Windows.Forms.Padding(1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Inteligência Nescessária";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(5, 232);
            this.label6.Margin = new System.Windows.Forms.Padding(1);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(210, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "Dextreza Nescessária:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(5, 275);
            this.label7.Margin = new System.Windows.Forms.Padding(1);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Constituição Nescessária:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(5, 490);
            this.label8.Margin = new System.Windows.Forms.Padding(1);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(210, 15);
            this.label8.TabIndex = 24;
            this.label8.Text = "Efeito Anct:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(5, 442);
            this.label9.Margin = new System.Windows.Forms.Padding(1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(210, 15);
            this.label9.TabIndex = 22;
            this.label9.Text = "Item Acient / Lendário";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(5, 361);
            this.label11.Margin = new System.Windows.Forms.Padding(1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(210, 15);
            this.label11.TabIndex = 18;
            this.label11.Text = "Item Grade ( A N M...)";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(5, 318);
            this.label12.Margin = new System.Windows.Forms.Padding(1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(210, 15);
            this.label12.TabIndex = 16;
            this.label12.Text = "Valor do Item:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(76, 60);
            this.label13.Margin = new System.Windows.Forms.Padding(1);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 15);
            this.label13.TabIndex = 26;
            this.label13.Text = "Textura";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // EF1
            // 
            this.EF1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF1.FormattingEnabled = true;
            this.EF1.ItemHeight = 13;
            this.EF1.Location = new System.Drawing.Point(51, 17);
            this.EF1.Margin = new System.Windows.Forms.Padding(1);
            this.EF1.Name = "EF1";
            this.EF1.Size = new System.Drawing.Size(112, 21);
            this.EF1.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(1, 17);
            this.label14.Margin = new System.Windows.Forms.Padding(1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 21);
            this.label14.TabIndex = 28;
            this.label14.Text = "ADD1";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(1, 43);
            this.label15.Margin = new System.Windows.Forms.Padding(1);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 21);
            this.label15.TabIndex = 31;
            this.label15.Text = "ADD2";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF2
            // 
            this.EF2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF2.FormattingEnabled = true;
            this.EF2.ItemHeight = 13;
            this.EF2.Location = new System.Drawing.Point(51, 43);
            this.EF2.Margin = new System.Windows.Forms.Padding(1);
            this.EF2.Name = "EF2";
            this.EF2.Size = new System.Drawing.Size(112, 21);
            this.EF2.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(1, 69);
            this.label16.Margin = new System.Windows.Forms.Padding(1);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 21);
            this.label16.TabIndex = 34;
            this.label16.Text = "ADD3";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF3
            // 
            this.EF3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF3.FormattingEnabled = true;
            this.EF3.ItemHeight = 13;
            this.EF3.Location = new System.Drawing.Point(51, 69);
            this.EF3.Margin = new System.Windows.Forms.Padding(1);
            this.EF3.Name = "EF3";
            this.EF3.Size = new System.Drawing.Size(112, 21);
            this.EF3.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(1, 95);
            this.label17.Margin = new System.Windows.Forms.Padding(1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 21);
            this.label17.TabIndex = 37;
            this.label17.Text = "ADD4";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF4
            // 
            this.EF4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF4.FormattingEnabled = true;
            this.EF4.ItemHeight = 13;
            this.EF4.Location = new System.Drawing.Point(51, 95);
            this.EF4.Margin = new System.Windows.Forms.Padding(1);
            this.EF4.Name = "EF4";
            this.EF4.Size = new System.Drawing.Size(112, 21);
            this.EF4.TabIndex = 6;
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(1, 121);
            this.label18.Margin = new System.Windows.Forms.Padding(1);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 21);
            this.label18.TabIndex = 40;
            this.label18.Text = "ADD5";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF5
            // 
            this.EF5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF5.FormattingEnabled = true;
            this.EF5.ItemHeight = 13;
            this.EF5.Location = new System.Drawing.Point(51, 121);
            this.EF5.Margin = new System.Windows.Forms.Padding(1);
            this.EF5.Name = "EF5";
            this.EF5.Size = new System.Drawing.Size(112, 21);
            this.EF5.TabIndex = 8;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(1, 147);
            this.label19.Margin = new System.Windows.Forms.Padding(1);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 21);
            this.label19.TabIndex = 43;
            this.label19.Text = "ADD6";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF6
            // 
            this.EF6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF6.FormattingEnabled = true;
            this.EF6.ItemHeight = 13;
            this.EF6.Location = new System.Drawing.Point(51, 147);
            this.EF6.Margin = new System.Windows.Forms.Padding(1);
            this.EF6.Name = "EF6";
            this.EF6.Size = new System.Drawing.Size(112, 21);
            this.EF6.TabIndex = 10;
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(1, 173);
            this.label20.Margin = new System.Windows.Forms.Padding(1);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 21);
            this.label20.TabIndex = 46;
            this.label20.Text = "ADD7";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF7
            // 
            this.EF7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF7.FormattingEnabled = true;
            this.EF7.ItemHeight = 13;
            this.EF7.Location = new System.Drawing.Point(51, 173);
            this.EF7.Margin = new System.Windows.Forms.Padding(1);
            this.EF7.Name = "EF7";
            this.EF7.Size = new System.Drawing.Size(112, 21);
            this.EF7.TabIndex = 12;
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(1, 199);
            this.label21.Margin = new System.Windows.Forms.Padding(1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 21);
            this.label21.TabIndex = 49;
            this.label21.Text = "ADD8";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF8
            // 
            this.EF8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF8.FormattingEnabled = true;
            this.EF8.ItemHeight = 13;
            this.EF8.Location = new System.Drawing.Point(51, 199);
            this.EF8.Margin = new System.Windows.Forms.Padding(1);
            this.EF8.Name = "EF8";
            this.EF8.Size = new System.Drawing.Size(112, 21);
            this.EF8.TabIndex = 14;
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(1, 225);
            this.label22.Margin = new System.Windows.Forms.Padding(1);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 21);
            this.label22.TabIndex = 52;
            this.label22.Text = "ADD9";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF9
            // 
            this.EF9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF9.FormattingEnabled = true;
            this.EF9.ItemHeight = 13;
            this.EF9.Location = new System.Drawing.Point(51, 225);
            this.EF9.Margin = new System.Windows.Forms.Padding(1);
            this.EF9.Name = "EF9";
            this.EF9.Size = new System.Drawing.Size(112, 21);
            this.EF9.TabIndex = 16;
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(1, 251);
            this.label23.Margin = new System.Windows.Forms.Padding(1);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 21);
            this.label23.TabIndex = 55;
            this.label23.Text = "ADD10";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF10
            // 
            this.EF10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF10.FormattingEnabled = true;
            this.EF10.ItemHeight = 13;
            this.EF10.Location = new System.Drawing.Point(51, 251);
            this.EF10.Margin = new System.Windows.Forms.Padding(1);
            this.EF10.Name = "EF10";
            this.EF10.Size = new System.Drawing.Size(112, 21);
            this.EF10.TabIndex = 18;
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(1, 277);
            this.label24.Margin = new System.Windows.Forms.Padding(1);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 21);
            this.label24.TabIndex = 58;
            this.label24.Text = "ADD11";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF11
            // 
            this.EF11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF11.FormattingEnabled = true;
            this.EF11.ItemHeight = 13;
            this.EF11.Location = new System.Drawing.Point(51, 277);
            this.EF11.Margin = new System.Windows.Forms.Padding(1);
            this.EF11.Name = "EF11";
            this.EF11.Size = new System.Drawing.Size(112, 21);
            this.EF11.TabIndex = 20;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(1, 303);
            this.label25.Margin = new System.Windows.Forms.Padding(1);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(43, 21);
            this.label25.TabIndex = 61;
            this.label25.Text = "ADD12";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EF12
            // 
            this.EF12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EF12.FormattingEnabled = true;
            this.EF12.ItemHeight = 13;
            this.EF12.Location = new System.Drawing.Point(51, 303);
            this.EF12.Margin = new System.Windows.Forms.Padding(1);
            this.EF12.Name = "EF12";
            this.EF12.Size = new System.Drawing.Size(112, 21);
            this.EF12.TabIndex = 22;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.EFV12);
            this.groupBox1.Controls.Add(this.EFV11);
            this.groupBox1.Controls.Add(this.EFV10);
            this.groupBox1.Controls.Add(this.EFV9);
            this.groupBox1.Controls.Add(this.EFV8);
            this.groupBox1.Controls.Add(this.EFV7);
            this.groupBox1.Controls.Add(this.EFV6);
            this.groupBox1.Controls.Add(this.EFV5);
            this.groupBox1.Controls.Add(this.EFV4);
            this.groupBox1.Controls.Add(this.EFV3);
            this.groupBox1.Controls.Add(this.EFV2);
            this.groupBox1.Controls.Add(this.EFV1);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.EF1);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.EF12);
            this.groupBox1.Controls.Add(this.EF2);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.EF11);
            this.groupBox1.Controls.Add(this.EF3);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.EF10);
            this.groupBox1.Controls.Add(this.EF4);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.EF9);
            this.groupBox1.Controls.Add(this.EF5);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.EF8);
            this.groupBox1.Controls.Add(this.EF6);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.EF7);
            this.groupBox1.Location = new System.Drawing.Point(462, 41);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 9);
            this.groupBox1.Size = new System.Drawing.Size(257, 334);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Adicionais";
            // 
            // EFV12
            // 
            this.EFV12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV12.Location = new System.Drawing.Point(165, 303);
            this.EFV12.Margin = new System.Windows.Forms.Padding(1);
            this.EFV12.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV12.Name = "EFV12";
            this.EFV12.Size = new System.Drawing.Size(79, 21);
            this.EFV12.TabIndex = 23;
            // 
            // EFV11
            // 
            this.EFV11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV11.Location = new System.Drawing.Point(165, 277);
            this.EFV11.Margin = new System.Windows.Forms.Padding(1);
            this.EFV11.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV11.Name = "EFV11";
            this.EFV11.Size = new System.Drawing.Size(79, 21);
            this.EFV11.TabIndex = 21;
            // 
            // EFV10
            // 
            this.EFV10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV10.Location = new System.Drawing.Point(165, 251);
            this.EFV10.Margin = new System.Windows.Forms.Padding(1);
            this.EFV10.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV10.Name = "EFV10";
            this.EFV10.Size = new System.Drawing.Size(79, 21);
            this.EFV10.TabIndex = 19;
            // 
            // EFV9
            // 
            this.EFV9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV9.Location = new System.Drawing.Point(165, 225);
            this.EFV9.Margin = new System.Windows.Forms.Padding(1);
            this.EFV9.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV9.Name = "EFV9";
            this.EFV9.Size = new System.Drawing.Size(79, 21);
            this.EFV9.TabIndex = 17;
            // 
            // EFV8
            // 
            this.EFV8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV8.Location = new System.Drawing.Point(165, 199);
            this.EFV8.Margin = new System.Windows.Forms.Padding(1);
            this.EFV8.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV8.Name = "EFV8";
            this.EFV8.Size = new System.Drawing.Size(79, 21);
            this.EFV8.TabIndex = 15;
            // 
            // EFV7
            // 
            this.EFV7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV7.Location = new System.Drawing.Point(165, 173);
            this.EFV7.Margin = new System.Windows.Forms.Padding(1);
            this.EFV7.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV7.Name = "EFV7";
            this.EFV7.Size = new System.Drawing.Size(79, 21);
            this.EFV7.TabIndex = 13;
            // 
            // EFV6
            // 
            this.EFV6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV6.Location = new System.Drawing.Point(165, 147);
            this.EFV6.Margin = new System.Windows.Forms.Padding(1);
            this.EFV6.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV6.Name = "EFV6";
            this.EFV6.Size = new System.Drawing.Size(79, 21);
            this.EFV6.TabIndex = 11;
            // 
            // EFV5
            // 
            this.EFV5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV5.Location = new System.Drawing.Point(165, 121);
            this.EFV5.Margin = new System.Windows.Forms.Padding(1);
            this.EFV5.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV5.Name = "EFV5";
            this.EFV5.Size = new System.Drawing.Size(79, 21);
            this.EFV5.TabIndex = 9;
            // 
            // EFV4
            // 
            this.EFV4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV4.Location = new System.Drawing.Point(165, 95);
            this.EFV4.Margin = new System.Windows.Forms.Padding(1);
            this.EFV4.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV4.Name = "EFV4";
            this.EFV4.Size = new System.Drawing.Size(79, 21);
            this.EFV4.TabIndex = 7;
            // 
            // EFV3
            // 
            this.EFV3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV3.Location = new System.Drawing.Point(165, 69);
            this.EFV3.Margin = new System.Windows.Forms.Padding(1);
            this.EFV3.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV3.Name = "EFV3";
            this.EFV3.Size = new System.Drawing.Size(79, 21);
            this.EFV3.TabIndex = 5;
            // 
            // EFV2
            // 
            this.EFV2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV2.Location = new System.Drawing.Point(165, 43);
            this.EFV2.Margin = new System.Windows.Forms.Padding(1);
            this.EFV2.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV2.Name = "EFV2";
            this.EFV2.Size = new System.Drawing.Size(79, 21);
            this.EFV2.TabIndex = 3;
            // 
            // EFV1
            // 
            this.EFV1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFV1.Location = new System.Drawing.Point(165, 17);
            this.EFV1.Margin = new System.Windows.Forms.Padding(1);
            this.EFV1.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.EFV1.Name = "EFV1";
            this.EFV1.Size = new System.Drawing.Size(79, 21);
            this.EFV1.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.Visual);
            this.groupBox2.Controls.Add(this.UNK4);
            this.groupBox2.Controls.Add(this.UNK3);
            this.groupBox2.Controls.Add(this.UNK2);
            this.groupBox2.Controls.Add(this.UNK1);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.grau);
            this.groupBox2.Controls.Add(this.anct);
            this.groupBox2.Controls.Add(this.unique);
            this.groupBox2.Controls.Add(this.preco);
            this.groupBox2.Controls.Add(this.constituicao);
            this.groupBox2.Controls.Add(this.destreza);
            this.groupBox2.Controls.Add(this.inteligencia);
            this.groupBox2.Controls.Add(this.forca);
            this.groupBox2.Controls.Add(this.level);
            this.groupBox2.Controls.Add(this.textura);
            this.groupBox2.Controls.Add(this.mesh);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.name);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(235, 41);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 9);
            this.groupBox2.Size = new System.Drawing.Size(223, 542);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Informações Gerais";
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(5, 473);
            this.label28.Margin = new System.Windows.Forms.Padding(1);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(210, 15);
            this.label28.TabIndex = 34;
            this.label28.Text = "ItemName";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(152, 60);
            this.label27.Margin = new System.Windows.Forms.Padding(1);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(63, 15);
            this.label27.TabIndex = 33;
            this.label27.Text = "SubMesh";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Visual
            // 
            this.Visual.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Visual.Location = new System.Drawing.Point(153, 77);
            this.Visual.Margin = new System.Windows.Forms.Padding(1);
            this.Visual.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.Visual.Name = "Visual";
            this.Visual.Size = new System.Drawing.Size(60, 21);
            this.Visual.TabIndex = 32;
            // 
            // UNK4
            // 
            this.UNK4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UNK4.Location = new System.Drawing.Point(174, 418);
            this.UNK4.Margin = new System.Windows.Forms.Padding(1);
            this.UNK4.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.UNK4.Name = "UNK4";
            this.UNK4.Size = new System.Drawing.Size(39, 21);
            this.UNK4.TabIndex = 31;
            // 
            // UNK3
            // 
            this.UNK3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UNK3.Location = new System.Drawing.Point(114, 418);
            this.UNK3.Margin = new System.Windows.Forms.Padding(1);
            this.UNK3.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.UNK3.Name = "UNK3";
            this.UNK3.Size = new System.Drawing.Size(39, 21);
            this.UNK3.TabIndex = 30;
            // 
            // UNK2
            // 
            this.UNK2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UNK2.Location = new System.Drawing.Point(57, 418);
            this.UNK2.Margin = new System.Windows.Forms.Padding(1);
            this.UNK2.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.UNK2.Name = "UNK2";
            this.UNK2.Size = new System.Drawing.Size(39, 21);
            this.UNK2.TabIndex = 29;
            // 
            // UNK1
            // 
            this.UNK1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UNK1.Location = new System.Drawing.Point(5, 418);
            this.UNK1.Margin = new System.Windows.Forms.Padding(1);
            this.UNK1.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.UNK1.Name = "UNK1";
            this.UNK1.Size = new System.Drawing.Size(39, 21);
            this.UNK1.TabIndex = 27;
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(5, 401);
            this.label26.Margin = new System.Windows.Forms.Padding(1);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(210, 15);
            this.label26.TabIndex = 28;
            this.label26.Text = "Unk1         Unk2       MountType     ID";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // grau
            // 
            this.grau.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grau.Location = new System.Drawing.Point(5, 507);
            this.grau.Margin = new System.Windows.Forms.Padding(1);
            this.grau.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.grau.Name = "grau";
            this.grau.Size = new System.Drawing.Size(210, 21);
            this.grau.TabIndex = 12;
            // 
            // anct
            // 
            this.anct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.anct.Location = new System.Drawing.Point(5, 457);
            this.anct.Margin = new System.Windows.Forms.Padding(1);
            this.anct.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.anct.Name = "anct";
            this.anct.Size = new System.Drawing.Size(210, 21);
            this.anct.TabIndex = 11;
            // 
            // unique
            // 
            this.unique.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unique.Location = new System.Drawing.Point(5, 378);
            this.unique.Margin = new System.Windows.Forms.Padding(1);
            this.unique.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.unique.Name = "unique";
            this.unique.Size = new System.Drawing.Size(210, 21);
            this.unique.TabIndex = 9;
            this.unique.ValueChanged += new System.EventHandler(this.unique_ValueChanged);
            // 
            // preco
            // 
            this.preco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preco.Location = new System.Drawing.Point(5, 335);
            this.preco.Margin = new System.Windows.Forms.Padding(1);
            this.preco.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.preco.Name = "preco";
            this.preco.Size = new System.Drawing.Size(210, 21);
            this.preco.TabIndex = 8;
            // 
            // constituicao
            // 
            this.constituicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.constituicao.Location = new System.Drawing.Point(5, 292);
            this.constituicao.Margin = new System.Windows.Forms.Padding(1);
            this.constituicao.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.constituicao.Name = "constituicao";
            this.constituicao.Size = new System.Drawing.Size(210, 21);
            this.constituicao.TabIndex = 7;
            // 
            // destreza
            // 
            this.destreza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.destreza.Location = new System.Drawing.Point(5, 249);
            this.destreza.Margin = new System.Windows.Forms.Padding(1);
            this.destreza.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.destreza.Name = "destreza";
            this.destreza.Size = new System.Drawing.Size(210, 21);
            this.destreza.TabIndex = 6;
            // 
            // inteligencia
            // 
            this.inteligencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inteligencia.Location = new System.Drawing.Point(5, 206);
            this.inteligencia.Margin = new System.Windows.Forms.Padding(1);
            this.inteligencia.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.inteligencia.Name = "inteligencia";
            this.inteligencia.Size = new System.Drawing.Size(210, 21);
            this.inteligencia.TabIndex = 5;
            // 
            // forca
            // 
            this.forca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forca.Location = new System.Drawing.Point(5, 163);
            this.forca.Margin = new System.Windows.Forms.Padding(1);
            this.forca.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.forca.Name = "forca";
            this.forca.Size = new System.Drawing.Size(210, 21);
            this.forca.TabIndex = 4;
            // 
            // level
            // 
            this.level.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level.Location = new System.Drawing.Point(5, 120);
            this.level.Margin = new System.Windows.Forms.Padding(1);
            this.level.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.level.Name = "level";
            this.level.Size = new System.Drawing.Size(210, 21);
            this.level.TabIndex = 3;
            // 
            // textura
            // 
            this.textura.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textura.Location = new System.Drawing.Point(79, 77);
            this.textura.Margin = new System.Windows.Forms.Padding(1);
            this.textura.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.textura.Name = "textura";
            this.textura.Size = new System.Drawing.Size(60, 21);
            this.textura.TabIndex = 2;
            // 
            // mesh
            // 
            this.mesh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mesh.Location = new System.Drawing.Point(5, 77);
            this.mesh.Margin = new System.Windows.Forms.Padding(1);
            this.mesh.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.mesh.Name = "mesh";
            this.mesh.Size = new System.Drawing.Size(62, 21);
            this.mesh.TabIndex = 1;
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(9, 15);
            this.save.Margin = new System.Windows.Forms.Padding(1);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(61, 30);
            this.save.TabIndex = 0;
            this.save.Text = "Salvar";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(78, 15);
            this.cancel.Margin = new System.Windows.Forms.Padding(1);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(61, 30);
            this.cancel.TabIndex = 1;
            this.cancel.Text = "Cancelar";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // saveall
            // 
            this.saveall.Location = new System.Drawing.Point(9, 49);
            this.saveall.Margin = new System.Windows.Forms.Padding(1);
            this.saveall.Name = "saveall";
            this.saveall.Size = new System.Drawing.Size(96, 30);
            this.saveall.TabIndex = 1;
            this.saveall.Text = "ItemList.bin";
            this.saveall.UseVisualStyleBackColor = true;
            this.saveall.Click += new System.EventHandler(this.saveall_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.posicao);
            this.groupBox3.Controls.Add(this.slot17);
            this.groupBox3.Controls.Add(this.slot16);
            this.groupBox3.Controls.Add(this.slot15);
            this.groupBox3.Controls.Add(this.slot14);
            this.groupBox3.Controls.Add(this.slot13);
            this.groupBox3.Controls.Add(this.slot12);
            this.groupBox3.Controls.Add(this.slot11);
            this.groupBox3.Controls.Add(this.slot10);
            this.groupBox3.Controls.Add(this.slot9);
            this.groupBox3.Controls.Add(this.slot8);
            this.groupBox3.Controls.Add(this.slot7);
            this.groupBox3.Controls.Add(this.slot6);
            this.groupBox3.Controls.Add(this.slot5);
            this.groupBox3.Controls.Add(this.slot4);
            this.groupBox3.Controls.Add(this.slot3);
            this.groupBox3.Controls.Add(this.slot2);
            this.groupBox3.Controls.Add(this.slot1);
            this.groupBox3.Controls.Add(this.slot0);
            this.groupBox3.Location = new System.Drawing.Point(463, 380);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(255, 203);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Local onde será equipado";
            // 
            // posicao
            // 
            this.posicao.Enabled = false;
            this.posicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posicao.Location = new System.Drawing.Point(176, 132);
            this.posicao.Margin = new System.Windows.Forms.Padding(1);
            this.posicao.MaxLength = 64;
            this.posicao.Name = "posicao";
            this.posicao.Size = new System.Drawing.Size(67, 21);
            this.posicao.TabIndex = 34;
            this.posicao.Text = "0";
            this.posicao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.posicao.Visible = false;
            // 
            // slot17
            // 
            this.slot17.AutoSize = true;
            this.slot17.Location = new System.Drawing.Point(176, 99);
            this.slot17.Margin = new System.Windows.Forms.Padding(1);
            this.slot17.Name = "slot17";
            this.slot17.Size = new System.Drawing.Size(59, 17);
            this.slot17.TabIndex = 18;
            this.slot17.Text = "Slot 17";
            this.slot17.UseVisualStyleBackColor = true;
            // 
            // slot16
            // 
            this.slot16.AutoSize = true;
            this.slot16.Location = new System.Drawing.Point(176, 80);
            this.slot16.Margin = new System.Windows.Forms.Padding(1);
            this.slot16.Name = "slot16";
            this.slot16.Size = new System.Drawing.Size(59, 17);
            this.slot16.TabIndex = 17;
            this.slot16.Text = "Slot 16";
            this.slot16.UseVisualStyleBackColor = true;
            // 
            // slot15
            // 
            this.slot15.AutoSize = true;
            this.slot15.Location = new System.Drawing.Point(176, 61);
            this.slot15.Margin = new System.Windows.Forms.Padding(1);
            this.slot15.Name = "slot15";
            this.slot15.Size = new System.Drawing.Size(59, 17);
            this.slot15.TabIndex = 16;
            this.slot15.Text = "Slot 15";
            this.slot15.UseVisualStyleBackColor = true;
            // 
            // slot14
            // 
            this.slot14.AutoSize = true;
            this.slot14.Location = new System.Drawing.Point(109, 155);
            this.slot14.Margin = new System.Windows.Forms.Padding(1);
            this.slot14.Name = "slot14";
            this.slot14.Size = new System.Drawing.Size(59, 17);
            this.slot14.TabIndex = 15;
            this.slot14.Text = "Slot 14";
            this.slot14.UseVisualStyleBackColor = true;
            // 
            // slot13
            // 
            this.slot13.AutoSize = true;
            this.slot13.Location = new System.Drawing.Point(109, 136);
            this.slot13.Margin = new System.Windows.Forms.Padding(1);
            this.slot13.Name = "slot13";
            this.slot13.Size = new System.Drawing.Size(59, 17);
            this.slot13.TabIndex = 14;
            this.slot13.Text = "Slot 13";
            this.slot13.UseVisualStyleBackColor = true;
            // 
            // slot12
            // 
            this.slot12.AutoSize = true;
            this.slot12.Location = new System.Drawing.Point(109, 117);
            this.slot12.Margin = new System.Windows.Forms.Padding(1);
            this.slot12.Name = "slot12";
            this.slot12.Size = new System.Drawing.Size(59, 17);
            this.slot12.TabIndex = 13;
            this.slot12.Text = "Slot 12";
            this.slot12.UseVisualStyleBackColor = true;
            // 
            // slot11
            // 
            this.slot11.AutoSize = true;
            this.slot11.Location = new System.Drawing.Point(109, 98);
            this.slot11.Margin = new System.Windows.Forms.Padding(1);
            this.slot11.Name = "slot11";
            this.slot11.Size = new System.Drawing.Size(59, 17);
            this.slot11.TabIndex = 12;
            this.slot11.Text = "Slot 11";
            this.slot11.UseVisualStyleBackColor = true;
            // 
            // slot10
            // 
            this.slot10.AutoSize = true;
            this.slot10.Location = new System.Drawing.Point(109, 79);
            this.slot10.Margin = new System.Windows.Forms.Padding(1);
            this.slot10.Name = "slot10";
            this.slot10.Size = new System.Drawing.Size(59, 17);
            this.slot10.TabIndex = 11;
            this.slot10.Text = "Slot 10";
            this.slot10.UseVisualStyleBackColor = true;
            // 
            // slot9
            // 
            this.slot9.AutoSize = true;
            this.slot9.Location = new System.Drawing.Point(109, 60);
            this.slot9.Margin = new System.Windows.Forms.Padding(1);
            this.slot9.Name = "slot9";
            this.slot9.Size = new System.Drawing.Size(53, 17);
            this.slot9.TabIndex = 10;
            this.slot9.Text = "Slot 9";
            this.slot9.UseVisualStyleBackColor = true;
            // 
            // slot8
            // 
            this.slot8.AutoSize = true;
            this.slot8.Location = new System.Drawing.Point(109, 41);
            this.slot8.Margin = new System.Windows.Forms.Padding(1);
            this.slot8.Name = "slot8";
            this.slot8.Size = new System.Drawing.Size(53, 17);
            this.slot8.TabIndex = 9;
            this.slot8.Text = "Slot 8";
            this.slot8.UseVisualStyleBackColor = true;
            // 
            // slot7
            // 
            this.slot7.AutoSize = true;
            this.slot7.Location = new System.Drawing.Point(176, 41);
            this.slot7.Margin = new System.Windows.Forms.Padding(1);
            this.slot7.Name = "slot7";
            this.slot7.Size = new System.Drawing.Size(53, 17);
            this.slot7.TabIndex = 8;
            this.slot7.Text = "Slot 7";
            this.slot7.UseVisualStyleBackColor = true;
            // 
            // slot6
            // 
            this.slot6.AutoSize = true;
            this.slot6.Location = new System.Drawing.Point(28, 156);
            this.slot6.Margin = new System.Windows.Forms.Padding(1);
            this.slot6.Name = "slot6";
            this.slot6.Size = new System.Drawing.Size(53, 17);
            this.slot6.TabIndex = 7;
            this.slot6.Text = "Slot 6";
            this.slot6.UseVisualStyleBackColor = true;
            // 
            // slot5
            // 
            this.slot5.AutoSize = true;
            this.slot5.Location = new System.Drawing.Point(28, 137);
            this.slot5.Margin = new System.Windows.Forms.Padding(1);
            this.slot5.Name = "slot5";
            this.slot5.Size = new System.Drawing.Size(53, 17);
            this.slot5.TabIndex = 6;
            this.slot5.Text = "Slot 5";
            this.slot5.UseVisualStyleBackColor = true;
            // 
            // slot4
            // 
            this.slot4.AutoSize = true;
            this.slot4.Location = new System.Drawing.Point(28, 118);
            this.slot4.Margin = new System.Windows.Forms.Padding(1);
            this.slot4.Name = "slot4";
            this.slot4.Size = new System.Drawing.Size(53, 17);
            this.slot4.TabIndex = 5;
            this.slot4.Text = "Slot 4";
            this.slot4.UseVisualStyleBackColor = true;
            // 
            // slot3
            // 
            this.slot3.AutoSize = true;
            this.slot3.Location = new System.Drawing.Point(28, 99);
            this.slot3.Margin = new System.Windows.Forms.Padding(1);
            this.slot3.Name = "slot3";
            this.slot3.Size = new System.Drawing.Size(53, 17);
            this.slot3.TabIndex = 4;
            this.slot3.Text = "Slot 3";
            this.slot3.UseVisualStyleBackColor = true;
            // 
            // slot2
            // 
            this.slot2.AutoSize = true;
            this.slot2.Location = new System.Drawing.Point(28, 80);
            this.slot2.Margin = new System.Windows.Forms.Padding(1);
            this.slot2.Name = "slot2";
            this.slot2.Size = new System.Drawing.Size(53, 17);
            this.slot2.TabIndex = 3;
            this.slot2.Text = "Slot 2";
            this.slot2.UseVisualStyleBackColor = true;
            // 
            // slot1
            // 
            this.slot1.AutoSize = true;
            this.slot1.Location = new System.Drawing.Point(28, 61);
            this.slot1.Margin = new System.Windows.Forms.Padding(1);
            this.slot1.Name = "slot1";
            this.slot1.Size = new System.Drawing.Size(53, 17);
            this.slot1.TabIndex = 2;
            this.slot1.Text = "Slot 1";
            this.slot1.UseVisualStyleBackColor = true;
            // 
            // slot0
            // 
            this.slot0.AutoSize = true;
            this.slot0.Location = new System.Drawing.Point(28, 42);
            this.slot0.Margin = new System.Windows.Forms.Padding(1);
            this.slot0.Name = "slot0";
            this.slot0.Size = new System.Drawing.Size(53, 17);
            this.slot0.TabIndex = 1;
            this.slot0.Text = "Slot 0";
            this.slot0.UseVisualStyleBackColor = true;
            // 
            // export
            // 
            this.export.Location = new System.Drawing.Point(9, 17);
            this.export.Margin = new System.Windows.Forms.Padding(1);
            this.export.Name = "export";
            this.export.Size = new System.Drawing.Size(96, 30);
            this.export.TabIndex = 0;
            this.export.Text = "ItemList.csv";
            this.export.UseVisualStyleBackColor = true;
            this.export.Click += new System.EventHandler(this.export_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.export);
            this.groupBox5.Controls.Add(this.saveall);
            this.groupBox5.Location = new System.Drawing.Point(5, 500);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(1);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(220, 83);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Salvar ItemList";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(111, 16);
            this.button3.Margin = new System.Windows.Forms.Padding(1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(96, 30);
            this.button3.TabIndex = 3;
            this.button3.Text = "ItemName.bin";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(107, 49);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 30);
            this.button1.TabIndex = 2;
            this.button1.Text = "ItemList.bin(Enc)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // itemBox
            // 
            this.itemBox.Controls.Add(this.clean);
            this.itemBox.Controls.Add(this.save);
            this.itemBox.Controls.Add(this.cancel);
            this.itemBox.Location = new System.Drawing.Point(5, 447);
            this.itemBox.Margin = new System.Windows.Forms.Padding(1);
            this.itemBox.Name = "itemBox";
            this.itemBox.Size = new System.Drawing.Size(220, 51);
            this.itemBox.TabIndex = 4;
            this.itemBox.TabStop = false;
            this.itemBox.Text = "Item Selcionado: ( 0 )";
            // 
            // clean
            // 
            this.clean.Location = new System.Drawing.Point(146, 15);
            this.clean.Margin = new System.Windows.Forms.Padding(1);
            this.clean.Name = "clean";
            this.clean.Size = new System.Drawing.Size(61, 30);
            this.clean.TabIndex = 2;
            this.clean.Text = "Limpar";
            this.clean.UseVisualStyleBackColor = true;
            this.clean.Click += new System.EventHandler(this.clean_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(10, 424);
            this.label10.Margin = new System.Windows.Forms.Padding(1);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(210, 15);
            this.label10.TabIndex = 34;
            this.label10.Text = "Quantidade de itens: ( 0 / 6500)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Pesquisa
            // 
            this.Pesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pesquisa.Location = new System.Drawing.Point(67, 41);
            this.Pesquisa.Margin = new System.Windows.Forms.Padding(1);
            this.Pesquisa.MaxLength = 64;
            this.Pesquisa.Name = "Pesquisa";
            this.Pesquisa.Size = new System.Drawing.Size(153, 21);
            this.Pesquisa.TabIndex = 35;
            this.Pesquisa.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(0, 41);
            this.button2.Margin = new System.Windows.Forms.Padding(1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(61, 21);
            this.button2.TabIndex = 3;
            this.button2.Text = "Buscar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.editorDeItemIonToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(722, 24);
            this.menuStrip1.TabIndex = 36;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirItemNamebinToolStripMenuItem,
            this.abrirItemListbinToolStripMenuItem,
            this.salvarItemListbinEncodeToolStripMenuItem,
            this.salvarItemListbinToolStripMenuItem,
            this.gerarItemNamecsvToolStripMenuItem,
            this.salvarItemNamebinToolStripMenuItem1,
            this.gerarItemNamecsvToolStripMenuItem1});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // abrirItemNamebinToolStripMenuItem
            // 
            this.abrirItemNamebinToolStripMenuItem.Enabled = false;
            this.abrirItemNamebinToolStripMenuItem.Name = "abrirItemNamebinToolStripMenuItem";
            this.abrirItemNamebinToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.abrirItemNamebinToolStripMenuItem.Text = "Abrir ItemName.bin";
            this.abrirItemNamebinToolStripMenuItem.Click += new System.EventHandler(this.abrirItemNamebinToolStripMenuItem_Click);
            // 
            // abrirItemListbinToolStripMenuItem
            // 
            this.abrirItemListbinToolStripMenuItem.Name = "abrirItemListbinToolStripMenuItem";
            this.abrirItemListbinToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.abrirItemListbinToolStripMenuItem.Text = "Abrir ItemList.bin";
            this.abrirItemListbinToolStripMenuItem.Click += new System.EventHandler(this.abrirItemListbinToolStripMenuItem_Click);
            // 
            // salvarItemListbinEncodeToolStripMenuItem
            // 
            this.salvarItemListbinEncodeToolStripMenuItem.Name = "salvarItemListbinEncodeToolStripMenuItem";
            this.salvarItemListbinEncodeToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.salvarItemListbinEncodeToolStripMenuItem.Text = "Salvar ItemList.bin(Encode)";
            this.salvarItemListbinEncodeToolStripMenuItem.Click += new System.EventHandler(this.salvarItemListbinEncodeToolStripMenuItem_Click);
            // 
            // salvarItemListbinToolStripMenuItem
            // 
            this.salvarItemListbinToolStripMenuItem.Name = "salvarItemListbinToolStripMenuItem";
            this.salvarItemListbinToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.salvarItemListbinToolStripMenuItem.Text = "Salvar itemList.bin";
            this.salvarItemListbinToolStripMenuItem.Click += new System.EventHandler(this.salvarItemListbinToolStripMenuItem_Click);
            // 
            // gerarItemNamecsvToolStripMenuItem
            // 
            this.gerarItemNamecsvToolStripMenuItem.Name = "gerarItemNamecsvToolStripMenuItem";
            this.gerarItemNamecsvToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.gerarItemNamecsvToolStripMenuItem.Text = "Gerar ItemList.csv";
            this.gerarItemNamecsvToolStripMenuItem.Click += new System.EventHandler(this.gerarItemNamecsvToolStripMenuItem_Click);
            // 
            // salvarItemNamebinToolStripMenuItem1
            // 
            this.salvarItemNamebinToolStripMenuItem1.Name = "salvarItemNamebinToolStripMenuItem1";
            this.salvarItemNamebinToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.salvarItemNamebinToolStripMenuItem1.Text = "Salvar ItemName.bin";
            this.salvarItemNamebinToolStripMenuItem1.Click += new System.EventHandler(this.salvarItemNamebinToolStripMenuItem1_Click);
            // 
            // gerarItemNamecsvToolStripMenuItem1
            // 
            this.gerarItemNamecsvToolStripMenuItem1.Name = "gerarItemNamecsvToolStripMenuItem1";
            this.gerarItemNamecsvToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.gerarItemNamecsvToolStripMenuItem1.Text = "Gerar ItemName.csv";
            this.gerarItemNamecsvToolStripMenuItem1.Click += new System.EventHandler(this.gerarItemNamecsvToolStripMenuItem1_Click);
            // 
            // editorDeItemIonToolStripMenuItem
            // 
            this.editorDeItemIonToolStripMenuItem.Name = "editorDeItemIonToolStripMenuItem";
            this.editorDeItemIonToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.editorDeItemIonToolStripMenuItem.Text = "Editor de ItemIcon";
            this.editorDeItemIonToolStripMenuItem.Click += new System.EventHandler(this.editorDeItemIonToolStripMenuItem_Click);
            // 
            // W2_ItemListEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(722, 588);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Pesquisa);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.itemBox);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "W2_ItemListEditor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "W2 - ItemList Editor";
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.EFV12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EFV1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Visual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UNK1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unique)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.preco)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.constituicao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.destreza)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inteligencia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.forca)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textura)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mesh)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.itemBox.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox listBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox name;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.ComboBox EF1;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.ComboBox EF2;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.ComboBox EF3;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.ComboBox EF4;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.ComboBox EF5;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.ComboBox EF6;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.ComboBox EF7;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.ComboBox EF8;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.ComboBox EF9;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.ComboBox EF10;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.ComboBox EF11;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.ComboBox EF12;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.NumericUpDown EFV12;
		private System.Windows.Forms.NumericUpDown EFV11;
		private System.Windows.Forms.NumericUpDown EFV10;
		private System.Windows.Forms.NumericUpDown EFV9;
		private System.Windows.Forms.NumericUpDown EFV8;
		private System.Windows.Forms.NumericUpDown EFV7;
		private System.Windows.Forms.NumericUpDown EFV6;
		private System.Windows.Forms.NumericUpDown EFV5;
		private System.Windows.Forms.NumericUpDown EFV4;
		private System.Windows.Forms.NumericUpDown EFV3;
		private System.Windows.Forms.NumericUpDown EFV2;
		private System.Windows.Forms.NumericUpDown EFV1;
		private System.Windows.Forms.NumericUpDown grau;
		private System.Windows.Forms.NumericUpDown anct;
		private System.Windows.Forms.NumericUpDown unique;
		private System.Windows.Forms.NumericUpDown preco;
		private System.Windows.Forms.NumericUpDown constituicao;
		private System.Windows.Forms.NumericUpDown destreza;
		private System.Windows.Forms.NumericUpDown inteligencia;
		private System.Windows.Forms.NumericUpDown forca;
		private System.Windows.Forms.NumericUpDown level;
		private System.Windows.Forms.NumericUpDown textura;
		private System.Windows.Forms.NumericUpDown mesh;
		private System.Windows.Forms.Button save;
		private System.Windows.Forms.Button cancel;
		private System.Windows.Forms.Button saveall;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.CheckBox slot15;
		private System.Windows.Forms.CheckBox slot14;
		private System.Windows.Forms.CheckBox slot13;
		private System.Windows.Forms.CheckBox slot12;
		private System.Windows.Forms.CheckBox slot11;
		private System.Windows.Forms.CheckBox slot10;
		private System.Windows.Forms.CheckBox slot9;
		private System.Windows.Forms.CheckBox slot8;
		private System.Windows.Forms.CheckBox slot7;
		private System.Windows.Forms.CheckBox slot6;
		private System.Windows.Forms.CheckBox slot5;
		private System.Windows.Forms.CheckBox slot4;
		private System.Windows.Forms.CheckBox slot3;
		private System.Windows.Forms.CheckBox slot2;
		private System.Windows.Forms.CheckBox slot1;
		private System.Windows.Forms.CheckBox slot0;
		private System.Windows.Forms.Button export;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.GroupBox itemBox;
		private System.Windows.Forms.Button clean;
        private System.Windows.Forms.CheckBox slot17;
        private System.Windows.Forms.CheckBox slot16;
        private System.Windows.Forms.NumericUpDown UNK4;
        private System.Windows.Forms.NumericUpDown UNK3;
        private System.Windows.Forms.NumericUpDown UNK2;
        private System.Windows.Forms.NumericUpDown UNK1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown Visual;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox posicao;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox Pesquisa;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirItemNamebinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirItemListbinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarItemListbinEncodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarItemListbinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerarItemNamecsvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarItemNamebinToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gerarItemNamecsvToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editorDeItemIonToolStripMenuItem;
    }
}

