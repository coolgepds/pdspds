﻿namespace W2___MixList
{
    partial class W2MixList
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(W2MixList));
            this.button1 = new System.Windows.Forms.Button();
            this.NPCList = new System.Windows.Forms.ListBox();
            this.txtGold = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtItem = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMapY = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTipo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtItem1 = new System.Windows.Forms.TextBox();
            this.txtItem2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtItem3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtItem4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtItem5 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtItem6 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtItem7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtItem8 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtMapX = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.restante = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nameNPC = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtFace = new System.Windows.Forms.Label();
            this.textFace = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.RequestList = new System.Windows.Forms.ListBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.txtUnk = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtUnused2 = new System.Windows.Forms.TextBox();
            this.txtUnused = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtMax2 = new System.Windows.Forms.TextBox();
            this.txtMin2 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtMax1 = new System.Windows.Forms.TextBox();
            this.txtMin1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.reqID = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtMax0 = new System.Windows.Forms.TextBox();
            this.txtMin0 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtStrdef = new System.Windows.Forms.TextBox();
            this.txtItemItens = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Salvar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // NPCList
            // 
            this.NPCList.FormattingEnabled = true;
            this.NPCList.Location = new System.Drawing.Point(16, 94);
            this.NPCList.Name = "NPCList";
            this.NPCList.Size = new System.Drawing.Size(237, 589);
            this.NPCList.TabIndex = 1;
            this.NPCList.SelectedIndexChanged += new System.EventHandler(this.lbNpc_SelectedIndexChanged);
            // 
            // txtGold
            // 
            this.txtGold.Location = new System.Drawing.Point(267, 141);
            this.txtGold.MaxLength = 10;
            this.txtGold.Name = "txtGold";
            this.txtGold.Size = new System.Drawing.Size(137, 20);
            this.txtGold.TabIndex = 2;
            this.txtGold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(211, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Gold:";
            // 
            // txtItem
            // 
            this.txtItem.Location = new System.Drawing.Point(295, 53);
            this.txtItem.Name = "txtItem";
            this.txtItem.Size = new System.Drawing.Size(118, 20);
            this.txtItem.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(259, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Item:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(93, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "MapX:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(178, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "MapY:";
            // 
            // txtMapY
            // 
            this.txtMapY.Location = new System.Drawing.Point(222, 24);
            this.txtMapY.MaxLength = 2;
            this.txtMapY.Name = "txtMapY";
            this.txtMapY.Size = new System.Drawing.Size(34, 20);
            this.txtMapY.TabIndex = 9;
            this.txtMapY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(262, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "PacketID:";
            // 
            // txtTipo
            // 
            this.txtTipo.Location = new System.Drawing.Point(323, 24);
            this.txtTipo.MaxLength = 6;
            this.txtTipo.Name = "txtTipo";
            this.txtTipo.Size = new System.Drawing.Size(90, 20);
            this.txtTipo.TabIndex = 11;
            this.txtTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Item 1:";
            // 
            // txtItem1
            // 
            this.txtItem1.Location = new System.Drawing.Point(68, 27);
            this.txtItem1.MaxLength = 6;
            this.txtItem1.Name = "txtItem1";
            this.txtItem1.Size = new System.Drawing.Size(132, 20);
            this.txtItem1.TabIndex = 14;
            // 
            // txtItem2
            // 
            this.txtItem2.Location = new System.Drawing.Point(267, 27);
            this.txtItem2.MaxLength = 6;
            this.txtItem2.Name = "txtItem2";
            this.txtItem2.Size = new System.Drawing.Size(137, 20);
            this.txtItem2.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(206, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Item 2:";
            // 
            // txtItem3
            // 
            this.txtItem3.Location = new System.Drawing.Point(68, 53);
            this.txtItem3.MaxLength = 6;
            this.txtItem3.Name = "txtItem3";
            this.txtItem3.Size = new System.Drawing.Size(132, 20);
            this.txtItem3.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Item 3:";
            // 
            // txtItem4
            // 
            this.txtItem4.Location = new System.Drawing.Point(267, 53);
            this.txtItem4.MaxLength = 6;
            this.txtItem4.Name = "txtItem4";
            this.txtItem4.Size = new System.Drawing.Size(137, 20);
            this.txtItem4.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(206, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Item 4:";
            // 
            // txtItem5
            // 
            this.txtItem5.Location = new System.Drawing.Point(68, 79);
            this.txtItem5.MaxLength = 6;
            this.txtItem5.Name = "txtItem5";
            this.txtItem5.Size = new System.Drawing.Size(132, 20);
            this.txtItem5.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Item 5:";
            // 
            // txtItem6
            // 
            this.txtItem6.Location = new System.Drawing.Point(267, 79);
            this.txtItem6.MaxLength = 6;
            this.txtItem6.Name = "txtItem6";
            this.txtItem6.Size = new System.Drawing.Size(137, 20);
            this.txtItem6.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(206, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Item 6:";
            // 
            // txtItem7
            // 
            this.txtItem7.Location = new System.Drawing.Point(68, 105);
            this.txtItem7.MaxLength = 6;
            this.txtItem7.Name = "txtItem7";
            this.txtItem7.Size = new System.Drawing.Size(132, 20);
            this.txtItem7.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 111);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Item 7:";
            // 
            // txtItem8
            // 
            this.txtItem8.Location = new System.Drawing.Point(267, 105);
            this.txtItem8.MaxLength = 6;
            this.txtItem8.Name = "txtItem8";
            this.txtItem8.Size = new System.Drawing.Size(137, 20);
            this.txtItem8.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(206, 108);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 13);
            this.label13.TabIndex = 27;
            this.label13.Text = "Item 8:";
            // 
            // txtMapX
            // 
            this.txtMapX.Location = new System.Drawing.Point(137, 24);
            this.txtMapX.MaxLength = 2;
            this.txtMapX.Name = "txtMapX";
            this.txtMapX.Size = new System.Drawing.Size(35, 20);
            this.txtMapX.TabIndex = 29;
            this.txtMapX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.restante);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.button11);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.button10);
            this.groupBox1.Controls.Add(this.NPCList);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(12, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(705, 692);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "NPCs";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // restante
            // 
            this.restante.AutoSize = true;
            this.restante.Location = new System.Drawing.Point(148, 65);
            this.restante.Name = "restante";
            this.restante.Size = new System.Drawing.Size(45, 13);
            this.restante.TabIndex = 42;
            this.restante.Text = " 0 / 100";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(18, 65);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(124, 13);
            this.label28.TabIndex = 29;
            this.label28.Text = "Composições Restantes:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtItem1);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.txtItem2);
            this.groupBox4.Controls.Add(this.txtItem8);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.txtGold);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.txtItem3);
            this.groupBox4.Controls.Add(this.txtItem7);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.txtItem4);
            this.groupBox4.Controls.Add(this.txtItem6);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.txtItem5);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(272, 110);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(426, 169);
            this.groupBox4.TabIndex = 41;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Composições ( Itens Requeridos)";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(94, 28);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(72, 23);
            this.button11.TabIndex = 34;
            this.button11.Text = "Limpar";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.nameNPC);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.txtFace);
            this.groupBox3.Controls.Add(this.textFace);
            this.groupBox3.Controls.Add(this.txtTipo);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtMapY);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txtMapX);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtItem);
            this.groupBox3.Location = new System.Drawing.Point(271, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(427, 85);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Configurção do NPC";
            // 
            // nameNPC
            // 
            this.nameNPC.Location = new System.Drawing.Point(49, 53);
            this.nameNPC.MaxLength = 64;
            this.nameNPC.Name = "nameNPC";
            this.nameNPC.Size = new System.Drawing.Size(207, 20);
            this.nameNPC.TabIndex = 41;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(5, 56);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(38, 13);
            this.label29.TabIndex = 40;
            this.label29.Text = "Name:";
            // 
            // txtFace
            // 
            this.txtFace.AutoSize = true;
            this.txtFace.Location = new System.Drawing.Point(2, 27);
            this.txtFace.Name = "txtFace";
            this.txtFace.Size = new System.Drawing.Size(34, 13);
            this.txtFace.TabIndex = 39;
            this.txtFace.Text = "Face:";
            // 
            // textFace
            // 
            this.textFace.Location = new System.Drawing.Point(49, 24);
            this.textFace.MaxLength = 3;
            this.textFace.Name = "textFace";
            this.textFace.Size = new System.Drawing.Size(38, 20);
            this.textFace.TabIndex = 38;
            this.textFace.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(172, 28);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(72, 23);
            this.button10.TabIndex = 33;
            this.button10.Text = "Recarregar";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.RequestList);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.button12);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.txtUnk);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.txtUnused2);
            this.groupBox2.Controls.Add(this.txtUnused);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.txtMax2);
            this.groupBox2.Controls.Add(this.txtMin2);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.txtMax1);
            this.groupBox2.Controls.Add(this.txtMin1);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.reqID);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.txtMax0);
            this.groupBox2.Controls.Add(this.txtMin0);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtAmount);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.txtStrdef);
            this.groupBox2.Controls.Add(this.txtItemItens);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Location = new System.Drawing.Point(272, 285);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(426, 397);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Composições";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(205, 344);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 23);
            this.button2.TabIndex = 40;
            this.button2.Text = "Limpar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(319, 206);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(22, 13);
            this.label27.TabIndex = 39;
            this.label27.Text = "até";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(319, 175);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(22, 13);
            this.label26.TabIndex = 38;
            this.label26.Text = "até";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(319, 147);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(22, 13);
            this.label22.TabIndex = 37;
            this.label22.Text = "até";
            // 
            // RequestList
            // 
            this.RequestList.FormattingEnabled = true;
            this.RequestList.Location = new System.Drawing.Point(11, 28);
            this.RequestList.Name = "RequestList";
            this.RequestList.Size = new System.Drawing.Size(170, 355);
            this.RequestList.TabIndex = 35;
            this.RequestList.SelectedIndexChanged += new System.EventHandler(this.requestBox_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label17.Location = new System.Drawing.Point(354, 381);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 13);
            this.label17.TabIndex = 32;
            this.label17.Text = "By SeitbNao";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(305, 344);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(94, 23);
            this.button12.TabIndex = 36;
            this.button12.Text = "Salvar";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(282, 291);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(50, 13);
            this.label25.TabIndex = 26;
            this.label25.Text = "Unknow:";
            // 
            // txtUnk
            // 
            this.txtUnk.Location = new System.Drawing.Point(203, 307);
            this.txtUnk.Name = "txtUnk";
            this.txtUnk.Size = new System.Drawing.Size(192, 20);
            this.txtUnk.TabIndex = 25;
            this.txtUnk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(199, 266);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(56, 13);
            this.label24.TabIndex = 24;
            this.label24.Text = "Unused 2:";
            // 
            // txtUnused2
            // 
            this.txtUnused2.Location = new System.Drawing.Point(264, 263);
            this.txtUnused2.Name = "txtUnused2";
            this.txtUnused2.Size = new System.Drawing.Size(131, 20);
            this.txtUnused2.TabIndex = 23;
            // 
            // txtUnused
            // 
            this.txtUnused.Location = new System.Drawing.Point(264, 237);
            this.txtUnused.Name = "txtUnused";
            this.txtUnused.Size = new System.Drawing.Size(131, 20);
            this.txtUnused.TabIndex = 21;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(199, 240);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 13);
            this.label23.TabIndex = 22;
            this.label23.Text = "Unused:";
            // 
            // txtMax2
            // 
            this.txtMax2.Location = new System.Drawing.Point(341, 203);
            this.txtMax2.MaxLength = 4;
            this.txtMax2.Name = "txtMax2";
            this.txtMax2.Size = new System.Drawing.Size(54, 20);
            this.txtMax2.TabIndex = 20;
            this.txtMax2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMin2
            // 
            this.txtMin2.Location = new System.Drawing.Point(264, 203);
            this.txtMin2.MaxLength = 4;
            this.txtMin2.Name = "txtMin2";
            this.txtMin2.Size = new System.Drawing.Size(54, 20);
            this.txtMin2.TabIndex = 18;
            this.txtMin2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(199, 206);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 13);
            this.label21.TabIndex = 19;
            this.label21.Text = "Min | Max [2]:";
            // 
            // txtMax1
            // 
            this.txtMax1.Location = new System.Drawing.Point(341, 172);
            this.txtMax1.MaxLength = 4;
            this.txtMax1.Name = "txtMax1";
            this.txtMax1.Size = new System.Drawing.Size(54, 20);
            this.txtMax1.TabIndex = 17;
            this.txtMax1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMin1
            // 
            this.txtMin1.Location = new System.Drawing.Point(264, 172);
            this.txtMin1.MaxLength = 4;
            this.txtMin1.Name = "txtMin1";
            this.txtMin1.Size = new System.Drawing.Size(54, 20);
            this.txtMin1.TabIndex = 15;
            this.txtMin1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(199, 175);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(70, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "Min | Max [1]:";
            // 
            // reqID
            // 
            this.reqID.AutoSize = true;
            this.reqID.Location = new System.Drawing.Point(302, 28);
            this.reqID.Name = "reqID";
            this.reqID.Size = new System.Drawing.Size(55, 13);
            this.reqID.TabIndex = 14;
            this.reqID.Text = "NENHUM";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(200, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 13);
            this.label19.TabIndex = 13;
            this.label19.Text = "Request Index: ";
            // 
            // txtMax0
            // 
            this.txtMax0.Location = new System.Drawing.Point(341, 144);
            this.txtMax0.MaxLength = 4;
            this.txtMax0.Name = "txtMax0";
            this.txtMax0.Size = new System.Drawing.Size(54, 20);
            this.txtMax0.TabIndex = 12;
            this.txtMax0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMin0
            // 
            this.txtMin0.Location = new System.Drawing.Point(264, 144);
            this.txtMin0.MaxLength = 4;
            this.txtMin0.Name = "txtMin0";
            this.txtMin0.Size = new System.Drawing.Size(54, 20);
            this.txtMin0.TabIndex = 10;
            this.txtMin0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(199, 147);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 13);
            this.label18.TabIndex = 11;
            this.label18.Text = "Min | Max [0]:";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(264, 73);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(131, 20);
            this.txtAmount.TabIndex = 8;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(199, 73);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 13);
            this.label16.TabIndex = 9;
            this.label16.Text = "Quantidade:";
            // 
            // txtStrdef
            // 
            this.txtStrdef.Location = new System.Drawing.Point(264, 97);
            this.txtStrdef.Name = "txtStrdef";
            this.txtStrdef.Size = new System.Drawing.Size(131, 20);
            this.txtStrdef.TabIndex = 6;
            // 
            // txtItemItens
            // 
            this.txtItemItens.Location = new System.Drawing.Point(264, 50);
            this.txtItemItens.Name = "txtItemItens";
            this.txtItemItens.Size = new System.Drawing.Size(131, 20);
            this.txtItemItens.TabIndex = 4;
            this.txtItemItens.TextChanged += new System.EventHandler(this.txtItemItens_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(199, 100);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(38, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Strdef:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(199, 53);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Item:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.richTextBox1);
            this.groupBox5.Location = new System.Drawing.Point(724, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(451, 693);
            this.groupBox5.TabIndex = 33;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Manual de Uso";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Enabled = false;
            this.richTextBox1.Location = new System.Drawing.Point(3, 16);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(445, 674);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // W2MixList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(1187, 717);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "W2MixList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "W2 - MixList Editor - WebCheats 755BR ~ 771KR";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox NPCList;
        private System.Windows.Forms.TextBox txtGold;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMapY;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTipo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtItem1;
        private System.Windows.Forms.TextBox txtItem2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtItem3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtItem4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtItem5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtItem6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtItem7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtItem8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtMapX;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtItemItens;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtStrdef;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtMax0;
        private System.Windows.Forms.TextBox txtMin0;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textFace;
        private System.Windows.Forms.Label txtFace;
        private System.Windows.Forms.Label reqID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtMax2;
        private System.Windows.Forms.TextBox txtMin2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtMax1;
        private System.Windows.Forms.TextBox txtMin1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtUnk;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtUnused2;
        private System.Windows.Forms.TextBox txtUnused;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ListBox RequestList;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label restante;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox nameNPC;
        private System.Windows.Forms.Label label29;
    }
}

